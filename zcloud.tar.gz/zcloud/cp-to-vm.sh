rsync -a . 10.211.55.15:~/zcloud
