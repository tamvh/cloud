/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: tamvh
 *
 * Created on January 10, 2016, 2:53 PM
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <memory>
#include <map>
#include <mutex>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int v1 = 10;
    int *p;
    p = &v1;
    *p += 100;


    cout << &p << endl;
    cout << v1 << endl;
    return 0;
}

