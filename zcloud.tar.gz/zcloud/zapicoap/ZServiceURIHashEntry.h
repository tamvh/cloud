/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZServiceURIHashEntry.h
 * Author: tamvh
 *
 * Created on May 9, 2016, 2:14 AM
 */

#ifndef ZSERVICEURIHASHENTRY_H
#define ZSERVICEURIHASHENTRY_H

#include <memory>

class ZServiceURIHashEntry {
public:

    ZServiceURIHashEntry(char *uri, int id, UT_hash_handle hh)
    : _uri(uri),
    _id(id),
    _hh(hh) {
    }
public:

    char *uri() const {
        return _uri;
    }

    int id() const {
        return _id;
    }
    
    UT_hash_handle hh() const{
        return _hh;
    }
private:
    typedef int (*ResourceCallback)(CoapPDU *pdu, int sockfd, struct sockaddr_storage *recvFrom);
    char *_uri;
    int _id;
    UT_hash_handle _hh;
};

#endif /* ZSERVICEURIHASHENTRY_H */

