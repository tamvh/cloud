/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZCoapWorker.h
 * Author: tamvh
 *
 * Created on April 7, 2016, 7:48 PM
 */

#ifndef ZCOAPWORKER_H
#define ZCOAPWORKER_H

#include <vector>
#include <iostream>
#include <memory>
#include <sys/types.h>
#include <sys/socket.h>
#define __USE_POSIX 1
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <math.h>
//#include <json-c/json.h>
#include "coap/nethelper.h"
#include "coap/coap.h"
#include "coap/uthash.h"
#include <Poco/BasicEvent.h>

#define BUF_LEN 500
#define URI_BUF_LEN 32

class ZServiceURIHashEntry;

class ZCoapWorker {
public:
    ZCoapWorker(const std::string& host, const std::string& port);
    virtual ~ZCoapWorker();
public:
    int connect(const std::string &host, const std::string &port);
    int callBack(CoapPDU *request, int sockfd, struct sockaddr_storage *recvFrom);

private:
    std::string _host;
    std::string _port;
    typedef int (*ResourceCallback)(CoapPDU *pdu, int sockfd, struct sockaddr_storage *recvFrom);

    struct URIHashEntry {
        const char *uri;
        ResourceCallback callback;
        int id;
        UT_hash_handle hh;
    };        
};

#endif /* ZCOAPWORKER_H */

