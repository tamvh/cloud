/* 
 * File:   ZApiCoap.cpp
 * Author: huuhoa
 * 
 * Created on October 24, 2015, 3:19 PM
 */
#include <sstream>

#include <Poco/Util/Application.h>
#include <Poco/Util/LayeredConfiguration.h>
#include <Poco/RegularExpression.h>
#include <Poco/JSON/Parser.h>
#include <Poco/JSON/Array.h>
#include <Poco/Delegate.h>

#include <zcommon/ZServiceInterface.h>
#include <zcommon/ZServiceLocator.h>
#include <zcommon/ZDBKey.h>
#include <zcommon/ErrorCode.h>
#include <zdb/ZDBProxy.h>
#include <zworker/ZWorker.h>
#include "zapicoap/ZCoapWorker.h"
#include "zapicoap/ZApiCoap.h"

using namespace std;
using Poco::Util::Application;
using Poco::Util::LayeredConfiguration;

class ZApiCoap::Impl {
public:
    Poco::SharedPtr<ZCoapWorker> coapWorker;
};

ZApiCoap::ZApiCoap() : d_ptr(new Impl) {
}

ZApiCoap::~ZApiCoap() {
}

bool ZApiCoap::initialize() {
    LayeredConfiguration& config = Application::instance().config();
    std::string port = config.getString("api.coap.port", "5683");
    std::string host = config.getString("api.coap.host", "localhost");
//    d_ptr->coapWorker = new ZCoapWorker(host, port);
    return true;
}

bool ZApiCoap::start() {
    return true;
}

bool ZApiCoap::stop() {
    return true;
}

bool ZApiCoap::cleanup() {
    return true;
}

