/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZCoapWorker.cpp
 * Author: tamvh
 * 
 * Created on April 7, 2016, 7:48 PM
 */
#include <Poco/Util/Application.h>
#include "zapicoap/ZCoapWorker.h"

using namespace std;
using Poco::Util::Application;


const int gNumResources = 1;
ZCoapWorker::ZCoapWorker(const std::string& host, const std::string& port) {
    int ret;
    Application& app = Application::instance();
    int sockfd = this->connect(host, port);
    // setup URI callbacks using uthash hash table
    struct URIHashEntry *entry = NULL, *directory = NULL, *hash = NULL;
    char *URIList[] ={(char *)"/test"};
      
    // create new hash structure to bind URI and callback
    entry = (struct URIHashEntry*) malloc(sizeof (struct URIHashEntry));
    entry->uri = URIList[0];
//    entry->callback = ;
    // add hash structure to hash table, note that key is the URI
    HASH_ADD_KEYPTR(hh, directory, entry->uri, strlen(entry->uri), entry);

    // buffers for UDP and URIs
    char buffer[BUF_LEN];
    char uriBuffer[URI_BUF_LEN];
    int recvURILen = 0;

    // storage for handling receive address
    struct sockaddr_storage recvAddr;
    socklen_t recvAddrLen = sizeof (struct sockaddr_storage);
    struct sockaddr_in *v4Addr;
    struct sockaddr_in6 *v6Addr;
    char straddr[INET6_ADDRSTRLEN];

    // reuse the same PDU
    CoapPDU *recvPDU = new CoapPDU((uint8_t*) buffer, BUF_LEN, BUF_LEN);

    // just block and handle one packet at a time in a single thread
    // you're not going to use this code for a production system are you ;)
    while (1) {
        // receive packet
        ret = recvfrom(sockfd, &buffer, BUF_LEN, 0, (sockaddr*) & recvAddr, &recvAddrLen);
        if (ret == -1) {
            app.logger().information("Error receiving data");
        }

        // print src address
        switch (recvAddr.ss_family) {
            case AF_INET:
                v4Addr = (struct sockaddr_in*) &recvAddr;
                //                app.logger().information("Got packet from " + (std::string)inet_ntoa(v4Addr->sin_addr) + " : " + (std::string)ntohs(v4Addr->sin_port));
                break;

            case AF_INET6:
                v6Addr = (struct sockaddr_in6*) &recvAddr;
                //                app.logger().information("Got packet from " + (std::string)inet_ntop(AF_INET6, &v6Addr->sin6_addr, straddr, sizeof (straddr)) + " : " + (std::string)ntohs(v6Addr->sin6_port));
                break;
        }

        // validate packet
        if (ret > BUF_LEN) {
            app.logger().information("PDU too large to fit in pre-allocated buffer");
            continue;
        }
        recvPDU->setPDULength(ret);
        if (recvPDU->validate() != 1) {
            app.logger().information("Malformed CoAP packet");
            continue;
        }
        app.logger().information("Valid CoAP PDU received");
        recvPDU->printHuman();

        // depending on what this is, maybe call callback function
        if (recvPDU->getURI(uriBuffer, URI_BUF_LEN, &recvURILen) != 0) {
            app.logger().information("Error retrieving URI");
            continue;
        }
        if (recvURILen == 0) {
            app.logger().information("There is no URI associated with this Coap PDU");
        } else {
            HASH_FIND_STR(directory, uriBuffer, hash);
            if (hash) {
                app.logger().information("Hash id is " + hash->id);
                hash->callback(recvPDU, sockfd, &recvAddr);
                continue;
            } else {
                app.logger().information("Hash not found.");
                continue;
            }
        }

        // no URI, handle cases

        // code==0, no payload, this is a ping request, send RST
        if (recvPDU->getPDULength() == 0 && recvPDU->getCode() == 0) {
            app.logger().information("CoAP ping request");
        }
        

    }
}

ZCoapWorker::~ZCoapWorker() {
}

int ZCoapWorker::connect(const std::string& host, const std::string& port) {
    Application& app = Application::instance();
    struct addrinfo *bindAddr;
    app.logger().information("Setting up bind address");
    int ret = setupAddress((char *) host.c_str(), (char *) port.c_str(), &bindAddr, SOCK_DGRAM, AF_INET);
    if (ret != 0) {
        app.logger().information("Error setting up bind address, exiting.");
        return -1;
    }
    // setup socket
    int sockfd = socket(bindAddr->ai_family, bindAddr->ai_socktype, bindAddr->ai_protocol);
    // call bind
    app.logger().information("Binding socket.");
    if (bind(sockfd, bindAddr->ai_addr, bindAddr->ai_addrlen) != 0) {
        app.logger().information("Error binding socket");
        return -1;
    }
    return sockfd;
}

int ZCoapWorker::callBack(CoapPDU *request, int sockfd, struct sockaddr_storage *recvFrom) {
    Application& app = Application::instance();
    socklen_t addrLen = sizeof (struct sockaddr_in);
    if (recvFrom->ss_family == AF_INET6) {
        addrLen = sizeof (struct sockaddr_in6);
    }
    app.logger().information("Callback function called");
    CoapPDU *response = new CoapPDU();
    response->setVersion(1);
    response->setMessageID(request->getMessageID());
    response->setToken(request->getTokenPointer(), request->getTokenLength());
    char *payload = (char*) "This is a mundanely worded test payload.";
    // respond differently, depending on method code
    switch (request->getCode()) {
        case CoapPDU::COAP_EMPTY:
            // makes no sense, send RST
            break;
        case CoapPDU::COAP_GET:
            response->setCode(CoapPDU::COAP_CONTENT);
            response->setContentFormat(CoapPDU::COAP_CONTENT_FORMAT_TEXT_PLAIN);
            response->setPayload((uint8_t*) payload, strlen(payload));
            break;
        case CoapPDU::COAP_POST:
            response->setCode(CoapPDU::COAP_CREATED);
            break;
        case CoapPDU::COAP_PUT:
            response->setCode(CoapPDU::COAP_CHANGED);
            break;
        case CoapPDU::COAP_DELETE:
            response->setCode(CoapPDU::COAP_DELETED);
            response->setPayload((uint8_t*) "DELETE OK", 9);
            break;
        default:
            break;
    }

    // type
    switch (request->getType()) {
        case CoapPDU::COAP_CONFIRMABLE:
            response->setType(CoapPDU::COAP_ACKNOWLEDGEMENT);
            break;
        case CoapPDU::COAP_NON_CONFIRMABLE:
            response->setType(CoapPDU::COAP_ACKNOWLEDGEMENT);
            break;
        case CoapPDU::COAP_ACKNOWLEDGEMENT:
            break;
        case CoapPDU::COAP_RESET:
            break;
        default:
            return 1;
            break;
    };

    // send the packet
    ssize_t sent = sendto(
            sockfd,
            response->getPDUPointer(),
            response->getPDULength(),
            0,
            (sockaddr*) recvFrom,
            addrLen
            );
    if (sent < 0) {
        app.logger().information("Error sending packet: " + sent);
        return 1;
    } else {
        app.logger().information("Sent: ", sent);
    }

    return 0;
}









