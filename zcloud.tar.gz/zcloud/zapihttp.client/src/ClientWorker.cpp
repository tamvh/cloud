/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClientWorker.cpp
 * Author: tamvh
 * 
 * Created on February 20, 2017, 4:00 PM
 */

#include "zapihttp.client/ClientWorker.h"
using namespace Poco;
using namespace Net;
using namespace std;
class ClientWorker::Impl {
public:
    std::string method;
    std::string data;
    std::string param;
    std::string reqBody;
    std::string path;
    std::string res_data;
    std::string _server;
    std::string _api;
    HTTPClientSession *session;
    HTTPResponse *response;
    HTTPRequest *request;
};

ClientWorker::ClientWorker(const std::string& server,
        const std::string& api) : d_ptr(new Impl) {
    d_ptr->_server = server;
    d_ptr->_api = api;    
}

ClientWorker::~ClientWorker() {
}

void ClientWorker::setMethod(const std::string method) {
    d_ptr->method = method;
}

void ClientWorker::setsParam(
        const std::string& key,
        const std::string& value) {
    if (!d_ptr->param.empty()) {
        d_ptr->param.append(",");
    }
    d_ptr->param.append("\"" + key + "\"");
    d_ptr->param.append(":");
    d_ptr->param.append("\"" + value + "\"");    
}
void ClientWorker::setiParam(
        const std::string& key,
        int value) {
    if (!d_ptr->param.empty()) {
        d_ptr->param.append(",");
    }
    d_ptr->param.append("\"" + key + "\"");
    d_ptr->param.append(":");
    d_ptr->param.append(std::to_string(value));    
}
void ClientWorker::setfParam(
        const std::string& key,
        float value) {
    if (!d_ptr->param.empty()) {
        d_ptr->param.append(",");
    }
    d_ptr->param.append("\"" + key + "\"");
    d_ptr->param.append(":");
    d_ptr->param.append(std::to_string(value));    
}
void ClientWorker::setlParam(
        const std::string& key,
        long value) {
    if (!d_ptr->param.empty()) {
        d_ptr->param.append(",");
    }
    d_ptr->param.append("\"" + key + "\"");
    d_ptr->param.append(":");
    d_ptr->param.append(std::to_string(value));    
}

void ClientWorker::sendRequest() {
    URI uri("http://iotlc.stats.vng.com.vn/api/datapoints");
    d_ptr->path = uri.getPathAndQuery();
    if (d_ptr->path.empty()) {
        d_ptr->path = "/";
    }
    HTTPClientSession session(uri.getHost(), uri.getPort()); 
    HTTPResponse response;    
    if (d_ptr->method == "POST") {
        //do post
        HTTPRequest request_post(HTTPRequest::HTTP_POST, d_ptr->path, HTTPMessage::HTTP_1_1);
        this->doPost(session, request_post, response);
    } else if (d_ptr->method == "GET") {
        //do get
        HTTPRequest request_get(HTTPRequest::HTTP_POST, d_ptr->path, HTTPMessage::HTTP_1_1);
        this->doGet(session, request_get, response);
    } else {
        cerr << "method invalid: " << d_ptr->method << endl;
    }
}

void ClientWorker::doGet(Poco::Net::HTTPClientSession& session, Poco::Net::HTTPRequest& request,Poco::Net::HTTPResponse& response) {
    session.sendRequest(request);
    std::istream& is = session.receiveResponse(response);
    std::string out_str = std::string(std::istreambuf_iterator<char>(is),{});
    d_ptr->res_data = out_str;
    std::cout << response.getStatus() << " " << response.getReason() << " " << out_str << std::endl;
}

void ClientWorker::doPost(Poco::Net::HTTPClientSession& session, Poco::Net::HTTPRequest& request,Poco::Net::HTTPResponse& response) {
    d_ptr->reqBody = "[{" + d_ptr->param + "}]";
//    std::string reqBody("[{\"name\": \"iotlab\", \"timestamp\": 1487651085, \"value\": 122.5}]");
    request.setContentLength(d_ptr->reqBody.length());
    std::ostream& os = session.sendRequest(request);
    os << d_ptr->reqBody; // sends the body
    request.write(std::cout);
    std::istream& is = session.receiveResponse(response);
    std::string out_str = std::string(std::istreambuf_iterator<char>(is),{});
    d_ptr->res_data = out_str;
}

std::string ClientWorker::responseData() {
    std::cout << "response data: " << d_ptr->res_data << std::endl;
    return d_ptr->res_data;
}