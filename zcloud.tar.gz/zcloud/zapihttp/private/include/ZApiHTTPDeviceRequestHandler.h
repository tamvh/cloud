/*
 * File:   ZApiHTTPDeviceRequestHandler.h
 * Author: huuhoa
 *
 * Created on November 8, 2015, 9:09 AM
 */

#ifndef ZAPIHTTPDEVICEREQUESTHANDLER_H
#define	ZAPIHTTPDEVICEREQUESTHANDLER_H

#include <memory>
#include <Poco/Dynamic/Var.h>
#include <zdevice/ZDeviceInfo.h>
#include <zdevice/ZVarLastestValue.h>
#include <zdevice/ZDevice.h>

#include <zapihttp/ZApiHTTPRequestBaseHandler.h>


class ZApiHTTPDeviceRequestHandler : public ZApiHTTPRequestBaseHandler {
public:
    ZApiHTTPDeviceRequestHandler(const std::string& requestPath);
    virtual ~ZApiHTTPDeviceRequestHandler();
public:
    static bool CanHandleRequest(const std::string& path, const std::string& method);
public:
    void handleRequest(Poco::Net::HTTPServerRequest& request, Poco::Net::HTTPServerResponse& response);
private:
    Poco::Dynamic::Var handleAddDIYDevice(Poco::Net::HTTPServerRequest& request);
    Poco::Dynamic::Var handleGetAllUserDevices(Poco::Net::HTTPServerRequest& request);
    Poco::Dynamic::Var handleAddIndieDevice(Poco::Net::HTTPServerRequest& request);
    Poco::Dynamic::Var handleUpdateDeviceWithId(Poco::Net::HTTPServerRequest& request, const std::string& address);
    Poco::Dynamic::Var handleGetDeviceWithId(Poco::Net::HTTPServerRequest& request, const std::string& address);
    Poco::Dynamic::Var handleDeleteDeviceWithId(Poco::Net::HTTPServerRequest& request, const std::string& address);
    Poco::Dynamic::Var handleAPIHttp(Poco::Net::HTTPServerRequest& request);
    Poco::Dynamic::Var handleAPIHttpRegister(Poco::JSON::Object::Ptr& params, const std::string& token);
    Poco::Dynamic::Var handleAPIHttpUpdate(Poco::JSON::Object::Ptr& params, const std::string& token);
    Poco::Dynamic::Var handleAPIHttpQuery(Poco::JSON::Object::Ptr& params, const std::string& token);
private:
    void fillJson(const std::shared_ptr<ZDeviceInfo> &device, Poco::JSON::Object::Ptr& responseData);
    void fillJsonAllDevices(const std::shared_ptr<ZDeviceInfo> &device, Poco::JSON::Array::Ptr& params, Poco::JSON::Object::Ptr& responseData);
    void fillJsonVarLastestValue(const std::shared_ptr<ZVarLastestValue> &varLastestValue, Poco::JSON::Object::Ptr& responseData);
    void fillJsonVarInfo(const std::shared_ptr<ZVarLastestValue> &varLastestValue, const std::string& varName, Poco::JSON::Object::Ptr& responseData);
    void fillJsonDetailDevice(const std::shared_ptr<ZDevice> &device, Poco::JSON::Array::Ptr & data, Poco::JSON::Object::Ptr& responseData);
    void fillJsonHttpUpdate(ZDeviceInfo::Ptr & device, Poco::JSON::Object::Ptr& responseData);
    void fillJsonHttpQuery(const std::shared_ptr<ZDevice> &device, Poco::JSON::Array::Ptr & data, Poco::JSON::Object::Ptr& responseData);
    //    std::string generateAccountClaims(const std::shared_ptr<ZUserInfo> &userInfo, Poco::JSON::Object::Ptr& responseData) const;
};

#endif	/* ZAPIHTTPDEVICEREQUESTHANDLER_H */

