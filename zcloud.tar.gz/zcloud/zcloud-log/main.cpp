/* 
 * File:   main.cpp
 * Author: huuhoa
 *
 * Created on October 23, 2015, 1:31 PM
 */

#include <cstdlib>
#include <iostream>
#include "ServerApp.h"
#include <Poco/Util/ServerApplication.h>

POCO_SERVER_MAIN(ServerApp)