/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZApiMQTT.cpp
 * Author: tamvh
 * 
 * Created on January 20, 2017, 10:49 AM
 */
#include <Poco/Util/Application.h>
#include <Poco/Util/LayeredConfiguration.h>
#include <Poco/RegularExpression.h>
#include <Poco/JSON/Parser.h>
#include <Poco/JSON/Array.h>
#include <Poco/Delegate.h>
#include <MQTTAsync.h>
#include "./MqttClientWorker.h"
#include "ZApiMQTT.h"

using namespace std;
using Poco::Util::Application;
using Poco::Util::LayeredConfiguration;

class ZApiMQTT::Impl {
public:
    typedef std::map<int64_t, Poco::JSON::Object::Ptr> ObjectMap;
    ObjectMap list_object_request;
    Poco::SharedPtr<MqttClientWorker> mqttClientWorker;
};

ZApiMQTT::ZApiMQTT() : d_ptr(new Impl) {
}

ZApiMQTT::~ZApiMQTT() {
}

bool ZApiMQTT::initialize() {
    LayeredConfiguration& config = Application::instance().config();
    unsigned short port = (unsigned short) config.getInt("api.mqtt.port", 1883);
    std::string host = config.getString("api.mqtt.host", "localhost");
    std::string clientId = config.getString("api.mqtt.clientId", "");
    std::string topic = config.getString("api.mqtt.topic", "/u/#");

    d_ptr->mqttClientWorker = new MqttClientWorker(clientId, host, port);
    d_ptr->mqttClientWorker->preSubscribe(topic, 0);
    d_ptr->mqttClientWorker->autoReconnect(true);
    d_ptr->mqttClientWorker->beginConnect();
    d_ptr->mqttClientWorker->connect();
    return true;
}

bool ZApiMQTT::start() {
    return true;
}

bool ZApiMQTT::stop() {
    return true;
}

bool ZApiMQTT::cleanup() {
    return true;
}

