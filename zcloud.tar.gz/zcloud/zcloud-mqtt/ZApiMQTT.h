/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZApiMQTT.h
 * Author: tamvh
 *
 * Created on January 20, 2017, 10:49 AM
 */

#ifndef ZAPIMQTT_H
#define ZAPIMQTT_H
#include <vector>
#include <sstream>
#include <iostream>
#include <memory>
#include <Poco/JSON/Object.h>
#include <zcommon/ZServiceInterface.h>

class ZApiMQTT : public ZServiceInterface{
public:
    ZApiMQTT();
    virtual ~ZApiMQTT();
public:
    virtual bool initialize();
    virtual bool start();
    virtual bool stop();
    virtual bool cleanup();
private:
    class Impl;
    std::shared_ptr<Impl> d_ptr;
};

#endif /* ZAPIMQTT_H */

