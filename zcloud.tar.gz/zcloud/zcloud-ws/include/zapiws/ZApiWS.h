/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ZApiWS.h
 * Author: tamvh
 *
 * Created on January 20, 2017, 2:31 PM
 */

#ifndef ZAPIWS_H
#define ZAPIWS_H

#include <memory>
#include <iostream>
#include <stdio.h>

#include <Poco/Net/WebSocket.h>
#include <zcommon/ZServiceInterface.h>

class WebSocketMessage;
class ServerPacket;

class ZApiWS : public ZServiceInterface {
public:
    ZApiWS();
    virtual ~ZApiWS();
public:
    virtual bool initialize();
    virtual bool start();
    virtual bool stop();
    virtual bool cleanup();

    void receive_message(std::shared_ptr<Poco::Net::WebSocket> websocket, const WebSocketMessage& msg);
    void send_client_list(const std::string& apikey, const std::string& msg);
private:
    void handle_client_login(std::shared_ptr<Poco::Net::WebSocket> websocket, const ServerPacket& clientData);
    void handle_client_logout(std::shared_ptr<Poco::Net::WebSocket> websocket, const ServerPacket& clientData);
public:
    void handle_client_logout(std::shared_ptr<Poco::Net::WebSocket> websocket);
private:
    class Impl;
    std::shared_ptr<Impl> d_ptr;
};

#endif /* ZAPIWS_H */

