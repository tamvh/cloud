#ifndef VERSION_H
#define VERSION_H

#include <string>

extern const std::string gGIT_VERSION;
extern const std::string gGIT_VERSION_SHORT;

#endif //VERSION_H
